#include <iostream>
using namespace std;
 
 int main () {
 	 float base , height , area ;
 	 cout << " Enter the base  " <<endl ;
 	 cin >> base ;
 	 cout << " Enter the height " <<endl ;
 	 cin >> height ;
 	 area = base * height ;
 	 cout << "The Area of Triangle = " << area ;
 	 
 }


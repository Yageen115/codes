#include <iostream>
 using namespace std ;
 
  
  int main  (){
  	cout << " enter the two number tha would you to built the permide " << endl;
  	int i , j , num1 , num2 ;
  	cin >> num1 >> num2 ;
  	for (i=0 ; i<num1 ; i++) {
  		
  		for (j=0 ; j <num2 ; j++) {
  			if  (j < i)
  				cout << "*" ;
			  
			  else 
			  	cout <<  " ";
			  
		  }
		  cout << endl ;
	  
}
  }
  

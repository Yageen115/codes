#include <iostream>

using namespace std;
int main () {
	int a=8  ;
	cout << (a+=2 )<< endl ;
    cout << (a*=2 )<< endl;
    cout << (a/=2 )<< endl;
    cout << (a%=2);
}

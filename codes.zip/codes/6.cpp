#include <iostream>
using namespace std ;

int main () {
	int x , y , z , w ;
	cout << "Enter x"  << endl ;
	cin >> x;
	cout << "Enter y"  << endl ;
	cin >> y;
	cout << "Enter z"  << endl ;
	cin >> z;
	cout << "Enter w"  << endl ;
	cin >> w;
	cout << (x== y + 1 || 7 * z != 12 - 1 && x == w / z) << endl ;
    cout << (w + 9 != 6 - 1 || 10 % z != x + 0);
	
}


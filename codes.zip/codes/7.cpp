#include <iostream>
 using namespace std ;
 
 int main () {
 	string first , last ;
 	cout << "Enter your first name" << endl  ;
 	cin >> first ;
 	cout << "Enter your last name" << endl ;
 	cin >> last ;
 	cout << last << " " << first;
 	
 }

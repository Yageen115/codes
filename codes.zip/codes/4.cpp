#include <iostream>
using namespace std ;

// FCI � Programming 1 � 2018 - Assignment 2
// Program Name: Bakhshali  method to calculate square root
// Last Modification Date: 3/3/2018
// Author1 and ID and Group: yageen mohamed .20170419 . G16
// Author2 and ID and Group: abdulrahman nouaman . 20170412 . G15
// Author3 and ID and Group: mohamed ayman . 20170286 . G15
// Teaching Assistant: Alyaa , Sammr

float sqroot(float sr)
{
    int pSq = 0;
	 //This will be the nearest perfect square to sr
    int m = 0; 
	//This is the sqrt of pSq
    
    //Find the nearest perfect square to sr
    for(int i = static_cast<int>(sr); i > 0; i--)
    {
        for(int j = 1; j < i; j++)
        {
            if(j*j == i)
            {
                pSq = i;
                m = j;
                break;
            }
        }
        if(pSq > 0)
            break;
    }
    
    float d = sr-pSq;
    float P = d/(2.0*m);
    float A = m+P;
    float sqrt_of_s = A-((P*P)/(2.0*A));
    return sqrt_of_s;
    
}

int main()
{
    float num;
    cout << "Enter a num: "  << endl ;
    cin >> num;
    float sqroot_of_num = sqroot(num);
    cout << "sqrt (" << num << ") = "   <<   sqroot_of_num  << endl;
    return 0;
}

#include <iostream>

using namespace std;

int main()
{
	cout <<"ahlan ya user ua habibi" << endl ;
	cout << "what you like to do today ?" << endl;
	cout << "cipher massege enter 1 " << endl << "decipher massege enter 2" << endl;
	int x;
	cin >> x;
   	if (x==1) {
	   
    string text ;
    cout << "Enter text :" ;
    cin >> text ;
    cout << endl ;
    int len = text.length() ;
    for (int i = 0 ; i < len ; i = i +4)
    {
        cout << text[i] ;
    }
    for (int i = 1 ; i < len ; i = i +2)
    {
        cout << text[i] ;
    }
    for (int i = 2 ; i < len ; i = i +4)
    {
        cout << text[i] ;
    }
}
    else {
    	 string text ;
    cout << "Enter text :" ;
    cin >> text ;
    cout << endl ;
    int len = text.length() ;
    for (int i = 0 ; i < len ; i = i +4)
    {
        cout << text[i] ;
    }
    for (int i = 1 ; i < len ; i = i +2)
    {
        cout << text[i] ;
    }
    for (int i = 2 ; i < len ; i = i +4)
    {
        cout << text[i] ;
    	
	}
}
 return 0 ;
}
